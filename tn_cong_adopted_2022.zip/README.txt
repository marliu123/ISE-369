2022 Tennesse Congressional Plan

##Redistricting Data Hub (RDH) Retrieval Date
02/21/203

##Sources
This dataset was retrieved via personal communication with the Tennessee General Assembly.

##Processing
The RDH did not modify any of the data.

##Additional Notes
Enclosed in this zip file the shapefile file for Tennessee's Congressional Districts ("Congress.shp") and supporting files.

To keep track of a state's adopted maps, go to All About Redistricting https://redistricting.lls.edu/
For any additional questions, please email info@redistrictingdatahub.or